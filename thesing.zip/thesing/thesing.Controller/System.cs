﻿using System;
using System.Collections.Generic;
using System.Text;

namespace thesing.Controller
{
    class System
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="receiver"></param>
        /// <param name="contente"></param>
        /// <returns></returns>
        public Boolean SendMail(string sender, List<string> receiver, string contente)
        {
            return true;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="receiver"></param>
        /// <param name="content"></param>
        /// <returns></returns>
        public Boolean SendMail(string sender, string receiver, string content)
        {
            return true;
        }
    }
}

