﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace thesing.Service
{
    class School
    {
        public string GetSchoolNameById(string id)
        {
            string result = "";

            return result;
        }
    }
}
