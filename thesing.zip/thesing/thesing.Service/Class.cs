﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace thesing.Service
{
    class Class
    {
        public string GetClassNameById(string id)
        {
            string result = "";

            return result;
        }

        public List<string> GetClassNameBySchoolId(string school)
        {
            List<string> result = new List<string>();

            return result;
        }
    }
}
