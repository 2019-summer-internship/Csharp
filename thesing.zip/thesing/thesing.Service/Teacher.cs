﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace thesing.Service
{
    class Teacher
    {
        public string GetTeacherNameById(string id)
        {
            string result = "";

            return result;
        }
    }
}
