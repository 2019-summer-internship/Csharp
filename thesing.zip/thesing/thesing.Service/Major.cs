﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace thesing.Service
{
    class Major
    {
        public string GetMajorNameById(string id)
        {
            string result = "";

            return result;
        }

        public List<string> GetMajorNameBySchoolId(string school)
        {
            List<string> result = new List<string>();

            return result;
        }
    }
}
